Faculty outcomes

Open faculty-outcomes.html directly in a modern browser. The game HTML is self-contained; graph images and Concept Review routing are embedded, so no sibling asset or concept-reviews folder is required.

Concept Review PDFs open from https://masteryquests.org/concept-reviews/ and require internet access only when a learner opens a recommended review. The game itself can still run from the downloaded HTML file.

The HTML is self-contained for local gameplay. Anonymous telemetry is OFF. Progress and game data stay in the learner’s browser. No email addresses are intentionally collected.

Enabled modes: Standard Campaign, Timed Trial, Exam Drill, Quiz, Unlimited Practice, Legendary Mode, Score Attack, Trial by Graph, Fading Fortune, Risk & Reward

Checkpoint questions are assigned by their published difficulty. Optional checkpoint focus only narrows which eligible concepts supply a checkpoint; it never changes ordinary-question availability or question difficulty.
